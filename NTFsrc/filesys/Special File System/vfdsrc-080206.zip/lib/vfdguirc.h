//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by vfdlib.rc
//
#define IDD_PROPDIALOG                  101
#define IDD_OPENDIALOG                  102
#define IDD_SAVEDIALOG                  103
#define IDI_VFD_ICON                    104
#define IDI_IMAGE_ICON                  105
#define IDI_CONFIG_ICON                 106
#define IDC_PROPERTY_TITLE              1001
#define IDC_COPYRIGHT_STR               1002
#define IDC_IMAGEFILE_LABEL             1003
#define IDC_IMAGEFILE                   1004
#define IDC_IMAGEDESC_LABEL             1005
#define IDC_IMAGEFILE_DESC              1006
#define IDC_IMAGEFILE_HINT              1007
#define IDC_TARGETFILE_LABEL            1008
#define IDC_TARGETFILE                  1009
#define IDC_DISKTYPE_LABEL              1010
#define IDC_DISKTYPE                    1011
#define IDC_DISKTYPE_FILE               1012
#define IDC_DISKTYPE_RAM                1013
#define IDC_MEDIATYPE_LABEL             1014
#define IDC_MEDIATYPE                   1015
#define IDC_WRITE_PROTECTED             1016
#define IDC_OPEN_PROTECTED              1017
#define IDC_BROWSE                      1018
#define IDC_OPEN                        1019
#define IDC_SAVE                        1020
#define IDC_CLOSE                       1021
#define IDC_FORMAT                      1022
#define IDC_CONTROL                     1023
#define IDC_OVERWRITE                   1024
#define IDC_TRUNCATE                    1025

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
