//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by vfdwin.rc
//
#define IDI_CONFIG_ICON                 101
#define IDI_OPEN_ICON                   102
#define IDI_IMAGE_ICON                  103
#define IDB_IMAGELIST                   104
#define IDR_ACCELERATOR                 105
#define IDD_MAIN                        110
#define IDD_IMAGE                       111
#define IDD_DRIVER                      112
#define IDD_ASSOC                       113
#define IDD_SHELL                       114
#define IDD_ABOUT                       115
#define IDD_NEWEXT                      116
#define IDD_LETTER                      117
#define IDC_TAB_CONTROL                 1000
#define IDC_LOG_MESSAGE                 1001
#define IDC_CURRENT_STATE               1002
#define IDC_LETTER_LABEL                1010
#define IDC_DRIVE_LETTER                1011
#define IDC_CHANGE                      1012
#define IDC_IMAGEFILE_LABEL             1013
#define IDC_IMAGEFILE                   1014
#define IDC_DESCRIPTION_LABEL           1015
#define IDC_DESCRIPTION                 1016
#define IDC_DISKTYPE_LABEL              1017
#define IDC_DISKTYPE                    1018
#define IDC_MEDIATYPE_LABEL             1019
#define IDC_MEDIATYPE                   1020
#define IDC_PROTECT                     1021
#define IDC_OPEN                        1022
#define IDC_SAVE                        1023
#define IDC_CLOSE                       1024
#define IDC_FORMAT                      1025
#define IDC_DRIVER_LABEL                1031
#define IDC_DRIVER_PATH                 1032
#define IDC_BROWSE                      1033
#define IDC_VERSION_LABEL               1034
#define IDC_VERSION                     1035
#define IDC_START_LABEL                 1036
#define IDC_START_MANUAL                1037
#define IDC_START_AUTO                  1038
#define IDC_INSTALL                     1039
#define IDC_START                       1040
#define IDC_STOP                        1041
#define IDC_REMOVE                      1042
#define IDC_ASSOC_LIST                  1051
#define IDC_ASSOC_MESSAGE               1052
#define IDC_NEW                         1053
#define IDC_ALL                         1054
#define IDC_CLEAR                       1055
#define IDC_APPLY                       1056
#define IDC_SHELL_TREE                  1061
#define IDC_ABOUT_TITLE                 1071
#define IDC_ABOUT_URL                   1072
#define IDC_ABOUT_HELP                  1073
#define IDC_ABOUT_COPYRIGHT             1074
#define IDC_NEWEXT_LABEL                1081
#define IDC_EXTENSION                   1082
#define IDC_PERSISTENT                  1083
#define IDC_REFRESH                     40001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1101
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
