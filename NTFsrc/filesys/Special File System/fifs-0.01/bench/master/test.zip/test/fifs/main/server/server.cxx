#include "smball.hxx"
#include "config.hxx"
#include "nbhelp.hxx"
#include "server.hxx"
#include "queue.hxx"
#include <debug.hxx>
#include <process.h> // for _beginthreadex
//#include <assert.h>

struct GlobalContext {
    DWORD connection;     // monotonically increasing (read/write)
    UCHAR lsn;            // the current lsn (read/write)
    CRITICAL_SECTION cs;
    BOOL running; // read-only...changes state once
    UCHAR nLana;  // read-only after first write
};

struct ReceiverContext {
    HANDLE hUnblockEvent;
};

static GlobalContext gc = { 0 };

static Queue WorkQ;
static Queue SendQ;

static HANDLE* hThreads;
static DWORD nThreads;
static HANDLE hEvent;

#define THREADAPI unsigned int WINAPI

static HINSTANCE hFs = 0;
FileSystem* pFs = 0;

int
InitServer()
{
    DFN(InitServer);
    hFs = LoadLibrary(config.fs_dll);
    if (!hFs) {
        DWORD error = GetLastError();
        DEBUG_PRINT(("could not get filesystem (0x%02x)\n", error));
        return FALSE;
    }
    FS_CREATE_PROC pFsCreate = 
        (FS_CREATE_PROC)GetProcAddress(hFs, FS_CREATE_PROC_NAME);
    if (!pFsCreate) {
        DWORD error = GetLastError();
        DEBUG_PRINT(("could not get filesystem create function (0x%02x)\n", 
                     error));
        return FALSE;
    }
    DWORD error = pFsCreate(config.fs_name, config.fs_config, 
                            FS_VERSION_0, &pFs);
    if (error) {
        DEBUG_PRINT(("could not instantiate filesystem interface (0x%08X)\n",
                     error));
        return FALSE;
    }

    gc.connection = 0;
    gc.lsn = 0;
    InitializeCriticalSection(&gc.cs);
    gc.running = FALSE;

    UCHAR code = NBFindFirstLanaWithNameN(config.nb_remote_name, &gc.nLana);
    if(!NB_SUCCESS(code)) {
        DEBUG_PRINT(("NBReset/Find error (0x%02x)\n", code));
        return FALSE;
    }

    if (!NB_SUCCESS(NBAddNameN(gc.nLana, config.nb_local_name, NULL))) {
        DEBUG_PRINT(("NBAddName error\n"));
        return FALSE;
    }
    smbutil_init();
    smbglue_init();
    return TRUE;
}

THREADAPI
ReceiverThread(
    LPVOID lpParameter
    )
{
    DFN(ReceiverThread);

    ReceiverContext* rc = (ReceiverContext*)lpParameter;
    Packet* p = NULL;
    HANDLE hEvents[2];
    UCHAR code;
    NCB ncb;
    DWORD waitobj;
    bool reconnect;

    DEBUG_PRINT(("started\n"));

    hEvents[0] = CreateEvent(NULL, FALSE, FALSE, NULL);
    hEvents[1] = rc->hUnblockEvent;
    BOOL first = TRUE;

    while (gc.running) {
        DEBUG_PRINT(("running...\n"));

        ResetEvent(hEvents[0]);
        code = NBListenExN(gc.nLana, 
                           config.debug?(PUCHAR)"*":config.nb_remote_name,
                           config.nb_local_name, 
                           0, NULL, hEvents[0], &ncb);
        if (!NB_SUCCESS(code)) {
            DEBUG_PRINT(("listening error 0x%02x\n", code));
            continue;  // need to abort somehow?...
        }

        DEBUG_PRINT(("listening...\n"));
        waitobj = WaitForMultipleObjects(2, hEvents, FALSE, INFINITE);
        if (waitobj == WAIT_OBJECT_0) {
            if (NB_SUCCESS(ncb.ncb_retcode)) {
                DEBUG_PRINT(("got a call on lsn %d!\n", ncb.ncb_lsn));
                EnterCriticalSection(&gc.cs);
                gc.connection++;
                gc.lsn = ncb.ncb_lsn;
                LeaveCriticalSection(&gc.cs);

                // we got a call, so we now receive...
                reconnect = 0;
                while(gc.running && !reconnect) {
                    if (!p) {
                        p = new Packet;
                        p->buffer = alloc_buffer(config.buffer_size);
                    }
                    EnterCriticalSection(&gc.cs);
                    p->connection = gc.connection;
                    p->lsn = gc.lsn;
                    LeaveCriticalSection(&gc.cs);
                    p->len = (USHORT)config.buffer_size;
                    ResetEvent(hEvents[0]);
                    DEBUG_PRINT(("receiving...\n"));
                    code = NBRecvEx(gc.nLana, p->lsn, p->buffer, &p->len, 
                                    hEvents[0], &ncb);
                    if (NB_BADSESSION(code)) {
                        DEBUG_PRINT(("session %d died...restarting...\n", 
                                     p->lsn));
                        reconnect = 1;
                    } else if (!NB_SUCCESS(code)) {
                        DEBUG_PRINT(("Netbios error 0x%02x\n", code));
                    } else {
                        DEBUG_PRINT(("waiting...\n"));
                        waitobj = WaitForMultipleObjects(2, hEvents, FALSE, 
                                                         INFINITE);
                        DEBUG_PRINT(("received!\n"));
                        if (waitobj == WAIT_OBJECT_0) {
                            if (NB_BADSESSION(ncb.ncb_retcode)) {
                                DEBUG_PRINT(("session %d died...restartin'...\n", 
                                             p->lsn));
                                reconnect = 1;
                            } else if (NB_SUCCESS(ncb.ncb_retcode)) {
                                p->len = ncb.ncb_length;
                                WorkQ.Add(p);
                                p = 0;
                            } else {
                                DEBUG_PRINT(("NBRecv error %d\n",
                                             ncb.ncb_retcode));
                            }
                        } else {
                            NBCancel(&ncb);
                        }
                    }
                }

            } else {
                DEBUG_PRINT(("asynch listening error 0x%02x\n", 
                             ncb.ncb_retcode));
            }
        } else {
            NBCancel(&ncb);
        }
    }
    DEBUG_PRINT(("exiting\n"));
    return 0;
}


THREADAPI
WorkerThread(
    LPVOID lpParameter
    )
{
    DFN(WorkerThread);
    bool printwait = true;
    DPB dpb;
    DEBUG_PRINT(("started\n"));
    while (gc.running) {
        if (printwait) DEBUG_PRINT(("waiting...\n"));
        dpb.p = (Packet*) WorkQ.Get();
        if (printwait = dpb.p) {
            DEBUG_PRINT(("working...\n"));
            if (IsSmb(dpb.p->buffer, dpb.p->len)) {

                dpb.in.smb = (PNT_SMB_HEADER)dpb.p->buffer;
                dpb.in.size = dpb.p->len;
                dpb.in.offset = sizeof(NT_SMB_HEADER);
                dpb.in.command = dpb.in.smb->Command;

                dpb.out.smb = (PNT_SMB_HEADER)alloc_buffer(config.buffer_size);
                dpb.out.size = config.buffer_size;
                dpb.out.valid = 0;

                DumpSmb(dpb.p->buffer, dpb.p->len, TRUE);
                DEBUG_PRINT(("dispatching...\n"));

                if(SmbDispatch(&dpb)) {
                    free_buffer(dpb.p->buffer);
                    dpb.p->buffer = (LPVOID)dpb.out.smb;
                    dpb.p->len = (USHORT)dpb.out.valid;

                    // DumpSmb(dpb.p->buffer, dpb.p->len, FALSE);

                    SendQ.Add(dpb.p);
                    dpb.p = 0;
                } else {
                    DEBUG_PRINT(("dispatch failed!\n"));
                    // did not understand...hangup on virtual circuit...
                    EnterCriticalSection(&gc.cs);
                    if (dpb.p->connection == gc.connection) {
                        DEBUG_PRINT(("hangup! -- disp failed on lsn %d\n", 
                                     dpb.p->lsn));
                        NBHangup(gc.nLana, dpb.p->lsn);
                    }
                    LeaveCriticalSection(&gc.cs);
                    free_buffer(dpb.out.smb);
                }
            }
            if (dpb.p) {
                free_buffer(dpb.p->buffer);
                delete dpb.p;
                dpb.p = 0;
            }
        }
        DEBUG_PRINT(("worked!\n"));
    }
    DEBUG_PRINT(("exiting\n"));
    return 0;
}

THREADAPI
SenderThread(
    LPVOID lpParameter
    )
{
    DFN(SenderThread);
    bool printwait = true;
    bool sending;
    Packet* p;
    UCHAR code;

    DEBUG_PRINT(("started\n"));
    while (gc.running) {
        if (printwait) DEBUG_PRINT(("waiting...\n"));
        p = (Packet*) SendQ.Get();
        if (printwait = p) {
            DEBUG_PRINT(("sending...\n"));
            EnterCriticalSection(&gc.cs);
            if (sending = (p->connection == gc.connection))
                code = NBSend(gc.nLana, p->lsn, p->buffer, &p->len);
            LeaveCriticalSection(&gc.cs);
            if (sending) {
                if (!NB_SUCCESS(code)) {
                    DEBUG_PRINT(("NBSend error %d\n", code));
                }
            } else {
                DEBUG_PRINT(("stale connection %d\n", p->connection));
            }
            free_buffer(p->buffer);
            delete p;
            p = 0;
        }
    }
    DEBUG_PRINT(("exiting\n"));
    return 0;
}

static ReceiverContext grc;

int
RunServer()
{
    const int nFixedThreads = 1;
    // start up 1 listener, 1 receiver, a few workers...
    gc.running = TRUE;
    grc.hUnblockEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
    nThreads = nFixedThreads + config.num_workers + config.num_senders;
    hThreads = new HANDLE[nThreads];
    hThreads[0] = (HANDLE)
        _beginthreadex(NULL, 0, &ReceiverThread, &grc, 0, NULL);
    DWORD i = nFixedThreads;
    for ( ; i < (config.num_workers + nFixedThreads); i++)
        hThreads[i] = (HANDLE)
            _beginthreadex(NULL, 0, &WorkerThread, NULL, 0, NULL);
    for ( ; i < nThreads; i++)
        hThreads[i] = (HANDLE)
            _beginthreadex(NULL, 0, &SenderThread, NULL, 0, NULL);
    return TRUE;
}

void CleanupServer()
{
    DFN(CleanupServer);
    if (gc.running) {
        gc.running = FALSE;
        DEBUG_PRINT(("waiting for threads to die off...\n"));
        SetEvent(grc.hUnblockEvent);
        WorkQ.Unblock();
        SendQ.Unblock();
        // wait for them to die of natural causes before we kill them...
        WaitForMultipleObjects(nThreads, hThreads, TRUE, config.kill_wait_time);
        for (DWORD i = 0; i < nThreads; i++) {
            TerminateThread(hThreads[i], 0); // in case they did not stop...
            CloseHandle(hThreads[i]);
        }
        CloseHandle(hEvent);
        delete hThreads;
    }
    smbglue_cleanup();
    smbutil_cleanup();
    if (hFs) FreeLibrary(hFs); // must do this last!
}
