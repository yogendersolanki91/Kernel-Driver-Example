#ifndef __CONFIG_HXX__
#define __CONFIG_HXX__

#include "nbhelp.hxx"

struct config_type {
    char remote_name[MAX_COMPUTERNAME_LENGTH + 1];
    char local_name[MAX_COMPUTERNAME_LENGTH + 1];
    NETBIOS_NAME nb_remote_name;
    NETBIOS_NAME nb_local_name;
    DWORD kill_wait_time;
    DWORD num_workers;
    DWORD num_senders;
    DWORD buffer_size;
    bool debug;
    char* fs_dll;
    char* fs_name;
    char* fs_config;
};

extern config_type config;

void InitConfig(const char* config_path);
void CleanupConfig();

#endif
