#include <windows.h>
#include <nb30.h>
#include "ncbutil.h"
#include <assert.h>

PNCB
AllocateNCB(
    )
{
    return malloc(sizeof(NCB));
}

VOID
FreeNCB(
    PNCB pncb
    )
{
    free(pncb);
}

// Build a name of length NCBNAMSZ, padding with spaces.
void
MakeNetbiosName(
    NETBIOS_NAME achDest,
    LPCSTR szSrc
    )
{
    int cchSrc;

    cchSrc = lstrlen (szSrc);
    if (cchSrc > NCBNAMSZ)
        cchSrc = NCBNAMSZ;

    memset (achDest, ' ', NCBNAMSZ);
    memcpy (achDest, szSrc, cchSrc);
}

VOID
InitializeNCB(
    PNCB pncb,
    int command,
    int nLana,
    int lsn,
    NETBIOS_NAME callname,
    NETBIOS_NAME name
    )
{
    assert(pncb);
    memset(pncb, 0, sizeof(NCB));
    pncb->ncb_command = command;
    pncb->ncb_lana_num = nLana;
    pncb->ncb_lsn = lsn;
    if (callname) {
        COPY_NETBIOS_NAME(pncb->ncb_callname, callname);
    }
    if (name) {
        COPY_NETBIOS_NAME(pncb->ncb_name, name);
    }
}
