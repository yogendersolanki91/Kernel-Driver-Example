#include "fsdt_munge.hxx"
#include <autolock.hxx>
#include <debug.hxx>

///////////////////////////////////////////////////////////////////////////////
//
// Implements filesystem dispatch table
//
///////////////////////////////////////////////////////////////////////////////

ULONG FsDT_Munge::global_count = 0;


ULONG
FsDT_Munge::AddRef(
    )
{
    AutoLock lock(&csObject);
    ULONG count = ref_count;
    ref_count++;
    return count;
}


ULONG
FsDT_Munge::Release(
    )
{
    EnterCriticalSection(&csObject);
    if (ref_count) ref_count--;
    ULONG count = ref_count;
    if (!ref_count) {
        delete this; // we delete csObject here...
    } else {
        LeaveCriticalSection(&csObject);
    }
    return count;
}


const char*
FsDT_Munge::get_principal()
{
    return pDT->get_principal();
}

fhandle_t
FsDT_Munge::get_root(
    )
{
    return 0;
}

DWORD
FsDT_Munge::create(
    fhandle_t dir, 
    const char* name, 
    UINT32 flags, 
    fattr_t* fattr, 
    fhandle_t* phandle
    )
{
    PathHandle p(dir, name, pDT);
    if (p.error()) return p.error();
    return pDT->create(p.dir(), p.name(), flags, fattr, phandle);
}


DWORD
FsDT_Munge::lookup(
    fhandle_t dir,
    const char* name,
    fattr_t* attr
    )
{
    PathHandle p(dir, name, pDT);
    if (p.error()) return p.error();
    return pDT->lookup(p.dir(), p.name(), attr);
}


DWORD
FsDT_Munge::remove(
    fhandle_t dir, 
    const char* name
    )
{
    PathHandle p(dir, name, pDT);
    if (p.error()) return p.error();
    return pDT->remove(p.dir(), p.name());
}

DWORD
FsDT_Munge::rename(
    fhandle_t from_dir, 
    const char* from_name, 
    fhandle_t to_dir, 
    const char* to_name
    )
{
    PathHandle pf(from_dir, from_name, pDT);
    if (pf.error()) return pf.error();
    PathHandle pt(to_dir, to_name, pDT);
    if (pt.error()) return pt.error();
    return pDT->rename(pf.dir(), pf.name(),
                       pt.dir(), pt.name());
}


DWORD
FsDT_Munge::mkdir(
    fhandle_t dir, 
    const char* name, 
    fattr_t* attr
    )
{
    PathHandle p(dir, name, pDT);
    if (p.error()) return p.error();
    return pDT->mkdir(p.dir(), p.name(), attr);
}


DWORD
FsDT_Munge::rmdir(
    fhandle_t dir, 
    const char* name
    )
{
    PathHandle p(dir, name, pDT);
    if (p.error()) return p.error();
    return pDT->rmdir(p.dir(), p.name());
}


DWORD
FsDT_Munge::set_attr(
    fhandle_t handle,
    fattr_t* attr
    )
{
    return pDT->set_attr(handle, attr);
}

DWORD
FsDT_Munge::get_attr(
    fhandle_t handle, 
    fattr_t* attr
    )
{
    return pDT->get_attr(handle, attr);
}


DWORD
FsDT_Munge::close(
    fhandle_t handle
    )
{
    return pDT->close(handle);
}

DWORD
FsDT_Munge::write(
    fhandle_t handle, 
    UINT64 offset, 
    UINT64* pcount, 
    void* buffer
    )
{
    return pDT->write(handle, offset, pcount, buffer);
}


DWORD
FsDT_Munge::read(
    fhandle_t handle, 
    UINT64 offset, 
    UINT64* pcount, 
    void* buffer
    )
{
    return pDT->read(handle, offset, pcount, buffer);
}


DWORD
FsDT_Munge::readlink(
    fhandle_t handle, 
    int* size, 
    char* path_buffer
    )
{
    return pDT->readlink(handle, size, path_buffer);
}


DWORD
FsDT_Munge::symlink(
    fhandle_t dir, 
    const char* name, 
    const char* path
    )
{
    return ERROR_CALL_NOT_IMPLEMENTED;
}


DWORD
FsDT_Munge::read_dir(
    fhandle_t dir, 
    UINT32 cookie, 
    dirinfo_t* buffer,
    UINT32 size, 
    UINT32 *entries_found
    )
{
    return pDT->read_dir(dir, cookie, buffer, size, entries_found);
}


DWORD
FsDT_Munge::statfs(
    fhandle_t handle, 
    fs_attr_t* attr
    )
{
    return pDT->statfs(handle, attr);
}


//
// constructor/destructor:
//


FsDT_Munge::FsDT_Munge(
    FsDispatchTable* _pDT,
    FileSystem* _pFs // caller must AddRef beforehand
    ):ref_count(1), pDT(_pDT), pFs(_pFs)
{
    InitializeCriticalSection(&csObject);
    global_count++;
}

FsDT_Munge::~FsDT_Munge(
    )
{
    pDT->Release();
    pFs->Release();
    DeleteCriticalSection(&csObject);
    global_count--;
}
