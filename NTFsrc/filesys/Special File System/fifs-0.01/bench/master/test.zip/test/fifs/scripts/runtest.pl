$HOME = "C:\\user\\dalmeida";
$SRC = $HOME."\\src";
$CONCEPT = $SRC."\\sfs-smb\\concept";
$VICE="c:\\usr\\vice\\PROGRAM";

$LOG_DIR = $CONCEPT."\\logs";
$LOG_FILE = "netbios.log";

$DIR_FSTEST = $CONCEPT."\\fstest\\debug";
$DIR_NETAPI32_SOURCE = $CONCEPT."\\netapi32\\debug";
$DIR_NETAPI32_TARGET = $VICE;

$DIR_TEST = "\\athena.mit.edu\\user\\d\\a\\dalmeida\\Public\\test";
$UNC_AFS = "\\\\cizeta-afs\\afs";
$DRIVE_AFS = "t:";

$NETAPI32_NAME = "netapi32.dll";
$NETAPI32_SOURCE = $DIR_NETAPI32_SOURCE."\\".$NETAPI32_NAME;
$NETAPI32_TARGET = $DIR_NETAPI32_TARGET."\\".$NETAPI32_NAME;

#####################################################################

sub CopyNetapi32
{
    system("cp $NETAPI32_SOURCE $NETAPI32_TARGET");
}

sub DelLog
{
    system("rm $LOG");
}

sub PrintArgs
{
    foreach $arg (@ARGV) {
        print "$arg\n";
    }
    print "count: $#ARGV\n";
}

sub GetLog
{
    if ($ARGV[0] =~ /\.log/i) {
        if ($ARGV[0] =~ /[\\\/]/) {
            $LOG = $ARGV[0];
        } else {
            $LOG = $LOG_DIR."\\".$ARGV[0];
        }
        shift(@ARGV);
    } else {
        $LOG = $LOG_DIR."\\".$LOG_FILE;
    }
    print "LOG = $LOG\n";
}

sub StartAfs
{
    system("net start \"Transarc AFS Daemon\"");
}

sub StopAfs
{
    sleep(2);
    system("net stop \"Transarc AFS Daemon\"");
}

sub TestStart
{
    &CopyNetapi32;
    &DelLog;
    &StartAfs;
}

sub TestEnd
{
    &StopAfs;
}

#####################################################################

sub TestDir
{
    &TestStart;
    system("ls -lF $UNC_AFS");
    &TestEnd;
}

sub TestDir2
{
    &TestStart;
    system("ls -lF $UNC_AFS$DIR_TEST\\*.test");
    &TestEnd;
}

sub TestFstest
{
    local($args) = "";
    local($arg);
    shift(@ARGV);
    foreach $arg (@ARGV) {
        $args = $args." ".$arg;
    }
    &TestStart;
    system("net use $DRIVE_AFS $UNC_AFS");
    system("$DIR_FSTEST\\fstest $args");
    system("net use $$DRIVE_AFS /d");
    &TestEnd;
}

sub Check
{
    shift(@ARGV);
    if ($ARGV[0] =~ /trans/i) {
        system("grep TRANS2 $LOG");
    } elsif ($ARGV[0] =~ /com/i) {
        system("egrep \"Command.*SMB_COM\" $LOG");
    } elsif ($ARGV[0] =~ /set/i) {
        system("egrep \"Setup\\[\" $LOG");
    } else {
        system("egrep \"(Command.*SMB_COM)|(TRANS2)\" $LOG");
    }
}

#####################################################################

#&PrintArgs;
&GetLog;
#&PrintArgs();

if ($ARGV[0] =~ /check/i) {
    &Check;
} elsif ($ARGV[0] =~ /dir/i) {
    &TestDir;
} elsif ($ARGV[0] =~ /dir2/i){
    &TestDir2;
} elsif ($ARGV[0] =~ /fstest/i){
    &TestFstest;
} else {
    print "Bye";
}
