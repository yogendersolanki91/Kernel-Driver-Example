#ifndef __BUFFERS_H__
#define __BUFFERS_H__

typedef struct _BUFFER_NODE {
    PVOID buffer;
    int size;
    struct _BUFFER_NODE *next;
} BUFFER_NODE, *PBUFFER_NODE;

typedef struct _BUFFER_LIST {
    BUFFER_NODE Head;
    PBUFFER_NODE pTail;
} BUFFER_LIST, *PBUFFER_LIST;

VOID
Buffers_Initialize(
    PBUFFER_LIST pBuffers,
    PVOID buffer,
    int size
    );

VOID
Buffers_Cleanup(
    PBUFFER_LIST pBuffers
    );

BOOL
Buffers_AddNode(
    PBUFFER_LIST pBuffers,
    int size
    );

BOOL
Buffers_Merge(
    PBUFFER_LIST pBuffers,
    int length,
    PVOID *ppBuffer
    );

PVOID
Buffers_GetNodeBuffer(
    PBUFFER_LIST pBuffers
    );

int
Buffers_GetNodeSize(
    PBUFFER_LIST pBuffers
    );

BOOL
Buffers_IsMultiNode(
    PBUFFER_LIST pBuffers
    );

#endif /* __BUFFLERS_H__ */
