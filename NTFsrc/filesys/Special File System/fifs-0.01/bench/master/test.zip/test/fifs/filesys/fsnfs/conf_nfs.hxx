#ifndef __CONFIG_HXX__
#define __CONFIG_HXX__

#include <rpc/rpc.h>

struct config_type {
    char localmachine[MAX_MACHINE_NAME + 1];
    char* machine;
    char* dirpath;
    char* protocol;
    char* label;
    HKEY hkey_user_info;
    unsigned long max_handles;
};

extern config_type config;

void InitConfig(const char* config_path);
void CleanupConfig();
DWORD GetUserInfo(const char* principal, int& uid, int& gid, int& len, 
                  int gids[], int maxlen);
#endif
