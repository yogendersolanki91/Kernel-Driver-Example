#ifndef __FSDT_WIN32_HXX__
#define __FSDT_WIN32_HXX__

#include "fs_win32.hxx"

///////////////////////////////////////////////////////////////////////////////
//
// Defines filesystem dispatch table
//
///////////////////////////////////////////////////////////////////////////////

class FsDT_Win32: public FsDispatchTable {
public:
    // FsDispatchTable:
    ULONG AddRef();
    ULONG Release();
    const char* get_principal();
    fhandle_t get_root();
    DWORD create(fhandle_t dir, const char* name, UINT32 flags, fattr_t* attr, fhandle_t* handle);
    DWORD set_attr(fhandle_t handle, fattr_t* attr);
    DWORD lookup(fhandle_t dir, const char* name, fattr_t* attr);
    DWORD get_attr(fhandle_t handle, fattr_t* attr);
    DWORD close(fhandle_t handle);
    DWORD write(fhandle_t handle, UINT64 offset, UINT64* count, void* buffer);
    DWORD read(fhandle_t handle,  UINT64 offset, UINT64* count, void* buffer);
    DWORD readlink(fhandle_t handle, int* size, char* path_buffer);
    DWORD symlink(fhandle_t dir, const char* name, const char* path);
    DWORD read_dir(fhandle_t dir, UINT32 cookie, dirinfo_t* buffer, UINT32 size, UINT32 *entries_found);
    DWORD statfs(fhandle_t handle, fs_attr_t* attr);
    DWORD remove(fhandle_t dir, const char* name);
    DWORD rename(fhandle_t fromdir, const char* fromname, fhandle_t todir, const char* toname);
    DWORD mkdir(fhandle_t dir, const char* name, fattr_t* attr);
    DWORD rmdir(fhandle_t dir, const char* name);

private:
    FsDT_Win32(const char* _principal, FileSystem* _pFs); // caller must AddRef
    ~FsDT_Win32();

    // helpers:
    DWORD init();
    DWORD create2(
        const char* fullname,
        size_t fullname_size, // including NULL byte...
        UINT32 flags, 
        fattr_t* fattr, 
        fhandle_t* phandle
        );
    DWORD close2(fhandle_t handle);
    inline fhandle_t get_new_handle();
    inline bool invalid_handle(fhandle_t handle);
    inline bool invalid_dir_handle(fhandle_t handle);
    inline bool invalid_file_handle(fhandle_t handle);

    // global:
    static ULONG global_count;
    inline static TIME64 get_time(FILETIME ft);
    inline static UINT32 get_attributes(DWORD a);
    inline static FILETIME unget_time(TIME64 t);
    inline static DWORD unget_attributes(UINT32 attr);
    inline static char* construct_pathname(const char* basename, const char* name);
    inline static void destroy_pathname(char* pathname);

    // types:
    struct dir_info_t {
        WIN32_FIND_DATA* cache;
        UINT32 capacity;
        UINT32 used;
        UINT32 max_cookie;
        bool done;
        void grow_cache(int n = 100) {
            WIN32_FIND_DATA* new_cache = new WIN32_FIND_DATA[capacity + n];
            RtlCopyMemory(new_cache, cache, sizeof(WIN32_FIND_DATA)*capacity);
            delete [] cache;
            cache = new_cache;
            capacity += n;
        }
        dir_info_t(int n = 100):
            cache(new WIN32_FIND_DATA[n]),
            capacity(n),
            used(0),
            max_cookie(0),
            done(false) {}
        ~dir_info_t() {
            delete [] cache;
        }
    };

    struct handle_info_t {
        HANDLE h;
        dir_info_t* pdi;
        char* pathname;

        handle_info_t():
            h(INVALID_HANDLE_VALUE),
            pdi(0),
            pathname(0) {}
    };

    // data:
    ULONG ref_count;
    FileSystem* pFs;
    char* principal;
    handle_info_t* handles;
    int handles_used;
    CRITICAL_SECTION csObject;

    // friends:
    friend class Fs_Win32;
};

#endif /* __FSDT_WIN32_HXX__ */
