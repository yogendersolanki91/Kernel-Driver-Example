#ifndef __CONFIG_H__
#define __CONFIG_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _config_string {
    BOOL allocated;
    LPCSTR string;
} config_string;

typedef struct _config_type {
    BOOL bShowLoad;
    BOOL bShowTime;
    BOOL bShowHeader;
    BOOL bShowBuffer;
    BOOL bShowBufferIffSmb;
    BOOL bShowSmb;
    config_string csRealPath;
    config_string csBoxTitle;
    config_string csLogFile;
} config_type;

extern config_type config;

void
InitConfig();

void
CleanupConfig();

#ifdef __cplusplus
}
#endif

#endif
