#ifndef __SMB_COM_H__
#define __SMB_COM_H__

BOOL
SmbComUnknown(
    DPB* dpb
    );

BOOL
SmbComNegotiate(
    DPB* dpb
    );

BOOL
SmbComSessionSetupAndx(
    DPB* dpb
    );

BOOL
SmbComTreeConnectAndx(
    DPB* dpb
    );

BOOL
SmbComNoAndx(
    DPB* dpb
    );

BOOL
SmbComTrans2(
    DPB* dpb
    );

BOOL
SmbComQueryInformation(
    DPB* dpb
    );

BOOL
SmbComSetInformation(
    DPB* dpb
    );

BOOL
SmbComCheckDirectory(
    DPB* dpb
    );

BOOL
SmbComFindClose2(
    DPB* dpb
    );

BOOL
SmbComDelete(
    DPB* dpb
    );

BOOL
SmbComRename(
    DPB* dpb
    );

BOOL
SmbComCreateDirectory(
    DPB* dpb
    );

BOOL
SmbComDeleteDirectory(
    DPB* dpb
    );

BOOL
SmbComOpenAndx(
    DPB* dpb
    );

BOOL
SmbComWrite(
    DPB* dpb
    );

BOOL
SmbComClose(
    DPB* dpb
    );

BOOL
SmbComReadAndx(
    DPB* dpb
    );

BOOL
SmbComQueryInformation2(
    DPB* dpb
    );

BOOL
SmbComSetInformation2(
    DPB* dpb
    );

BOOL
SmbComLockingAndx(
    DPB* dpb
    );

BOOL
SmbComSeek(
    DPB* dpb
    );

BOOL
SmbComLogoffAndx(
    DPB* dpb
    );

BOOL
SmbComTreeDisconnect(
    DPB* dpb
    );

#endif
