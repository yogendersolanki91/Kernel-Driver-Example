#ifndef __FS_WIN32_HXX__
#define __FS_WIN32_HXX__

#include <windows.h>
#include <fsinterface.hxx>

using namespace FsInterface;

///////////////////////////////////////////////////////////////////////////////
//
// Defines filesystem
//
///////////////////////////////////////////////////////////////////////////////

class Fs_Win32: public FileSystem {
public:
    ULONG AddRef();
    ULONG Release();
    
    DWORD connect(const char* principal, FsDispatchTable** ppDT);

private:
    Fs_Win32(const char* config_path);
    ~Fs_Win32();

    // helpers:
    DWORD init();

    // global:
    static ULONG global_count;

    // data:
    ULONG ref_count;
    CRITICAL_SECTION csObject;

    // friends:
    friend BOOL WINAPI DllMain(HINSTANCE, DWORD, LPVOID);
    friend DWORD WINAPI FileSystemCreate(LPCSTR, LPCSTR, DWORD, FileSystem**);
};

#endif /* __FS_WIN32_HXX__ */
