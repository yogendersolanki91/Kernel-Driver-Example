
/*++

Copyright (c) 1997 Microsoft Corporation

Module Name:

    mrxglbl.h

Abstract:

    The global include file for CIFS


--*/



#define INCLUDE_SMB_ALL

#include "status.h"
#include "smbtypes.h"
#include "smbmacro.h"
#include "smb.h"
#include "smbtrans.h"
#include "smbgtpt.h"
