#include <windows.h>
#include "config.hxx"
#include "server.hxx"
#include <debug.hxx>

static HANDLE hEvent;

BOOL WINAPI HandlerRoutine(DWORD dwCtrlType)
{
    switch(dwCtrlType) {
    case CTRL_C_EVENT:
    case CTRL_BREAK_EVENT:
    case CTRL_CLOSE_EVENT:
    case CTRL_LOGOFF_EVENT:
    case CTRL_SHUTDOWN_EVENT:
        SetEvent(hEvent);
        return TRUE;
    default:
        return FALSE;
    }
}

void Exit()
{
    CleanupServer();
    exit(1);
}

void main(int argc, char* argv[])
{
    DFN(main);
    InitConfig((argc > 1)?argv[1]:0);
    if (!InitServer()) Exit();
    if (!RunServer()) Exit();
    hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
    SetConsoleCtrlHandler(HandlerRoutine, TRUE);
    WaitForSingleObject(hEvent, INFINITE);
    DEBUG_PRINT(("cleaning up server\n"));
    CloseHandle(hEvent);
    CleanupServer();
    CleanupConfig();
}
