#ifndef __QUEUE_HXX__
#define __QUEUE_HXX__

struct Queue_Rep;

class Queue {
private:
    Queue_Rep* rep;
    void* Remove(void* handle);
public:
    Queue();
    ~Queue();
    void Add(void* data); // does not do anything if no data
    void* Get();
    void* Get(DWORD milliseconds);
    void Unblock();
    void Block();
};

#endif
