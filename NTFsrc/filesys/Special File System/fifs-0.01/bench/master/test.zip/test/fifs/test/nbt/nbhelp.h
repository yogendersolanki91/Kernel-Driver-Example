#define MAX_SESSIONS 0xFF
#define MAX_NAMES 0xFF

#define NBCheck(x)  if (NRC_GOODRET != (x)->ncb_retcode) { \
                        printf("%s Line %d: Got 0x%x from NetBios()\n", \
                               __FILE__, __LINE__, (x)->ncb_retcode); \
                    }

BOOL
NBReset(
    int nLana, 
    int nSessions, 
    int nNames
    );

BOOL
NBAddName(
    int nLana, 
    LPCSTR szName
    );

BOOL
NBListNames(
    int nLana,
    LPCSTR szName
    );

BOOL
NBAdapterStatus(
    int nLana,
    PVOID pBuffer,
    int cbBuffer,
    LPCSTR szName
    );

BOOL
NBEnumLana(
    int nLana
    );

VOID
NBDump(
    PNCB pncb
    );
