#include "fs_nfs.hxx"
#include "conf_nfs.hxx"
#include <rpc/rpc.h>

BOOL WINAPI 
DllMain(
    HINSTANCE hinstDLL, // handle to DLL module
    DWORD fdwReason, // reason for calling function
    LPVOID lpvReserved // reserved
    )
{
    switch (fdwReason) {
    case DLL_PROCESS_ATTACH:
        rpc_nt_init();
        break;
    case DLL_PROCESS_DETACH:
        if (Fs_NFS::global_count) return FALSE;
        rpc_nt_exit();
        break;
    case DLL_THREAD_ATTACH:
        break;
    case DLL_THREAD_DETACH:
        break;
    }
    return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
//
// Gets initial filesystem interface
//
///////////////////////////////////////////////////////////////////////////////

DWORD WINAPI
FileSystemCreate(
    LPCSTR name, // for the future... i.e., "NFSV3"..
    LPCSTR config_path,
    DWORD version,
    FileSystem** ppFs
    )
{
    if (!ppFs) return ERROR_INVALID_PARAMETER;
    *ppFs = 0;
    if (version != FS_VERSION_0) return ERROR_INVALID_FUNCTION;
    Fs_NFS* pFs = new Fs_NFS(config_path);
    DWORD error = pFs->init();
    if (error) {
        pFs->Release();
        return error;
    }
    *ppFs = pFs;
    return ERROR_SUCCESS;
}
