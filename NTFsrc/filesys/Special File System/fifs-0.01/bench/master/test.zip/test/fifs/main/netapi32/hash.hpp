#ifndef __INT_HASH_H__
#define __INT_HASH_H__

#ifdef __cplusplus

class IntHashBucket;

class IntHash {
private:
    IntHashBucket* m_table;
    int m_size;
    IntHashBucket& _Get(int);
public:
    IntHash(int size);
    ~IntHash();
    bool Get(int, void**);
    bool Del(int, void**);
    bool Add(int, void*);
};

#else

typedef void* IntHash;

void *IntHash_New(int size);
int IntHash_Get(void*, int, void**);
int IntHash_Del(void*, int, void**);
int IntHash_Add(void*, int, void*);
void IntHash_Free(void*);

#endif

#endif
