#ifndef __SMB_ALL_HXX__
#define __SMB_ALL_HXX__

#include <windows.h>
#include "mycifs.h"

#include "smbutil.hxx"
#include "smbcom.hxx"
#include "trans2.hxx"
#include "nbhelp.hxx"
#include "config.hxx"
#include "smbglue.hxx"
#include "fsinterface.hxx"

using namespace FsInterface;
extern FileSystem* pFs;

#endif
