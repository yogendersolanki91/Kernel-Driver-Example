#include "dispatch.hpp"

//extern "C" {
DECLARE_DISPATCH_FUNC(create);
DECLARE_DISPATCH_FUNC(df);
DECLARE_DISPATCH_FUNC(df2);
DECLARE_DISPATCH_FUNC(write);
DECLARE_DISPATCH_FUNC(contend);
DECLARE_DISPATCH_FUNC(contend2);
DECLARE_DISPATCH_FUNC(contend3);
//}

int main(int argc, char *argv[])
{
    CCommandLineDispatcher dispatcher;
    dispatcher.Add("create", create);
    dispatcher.Add("df", df);
    dispatcher.Add("df2", df2);
    dispatcher.Add("write", write);
    dispatcher.Add("contend", contend);
    dispatcher.Add("contend2", contend2);
    dispatcher.Add("contend3", contend3);
    return dispatcher.Dispatch(argc, argv);
}
