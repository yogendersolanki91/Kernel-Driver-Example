#ifndef __FS_MUNGE_HXX__
#define __FS_MUNGE_HXX__

#include <windows.h>
#include <fsinterface.hxx>

using namespace FsInterface;

///////////////////////////////////////////////////////////////////////////////
//
// Defines filesystem
//
///////////////////////////////////////////////////////////////////////////////

class Fs_Munge: public FileSystem {
public:
    ULONG AddRef();
    ULONG Release();
    
    DWORD connect(const char* principal, FsDispatchTable** ppDT);

private:
    Fs_Munge(const char* config_path);
    ~Fs_Munge();

    // helpers:
    DWORD init();

    // global:
    static ULONG global_count;

    // data:
    ULONG ref_count;
    CRITICAL_SECTION csObject;
    HINSTANCE hFs;
    FS_CREATE_PROC pFsCreate;
    FileSystem* pFs;

    // friends:
    friend BOOL WINAPI DllMain(HINSTANCE, DWORD, LPVOID);
    friend DWORD WINAPI FileSystemCreate(LPCSTR, LPCSTR, DWORD, FileSystem**);
};

#endif /* __FS_MUNGE_HXX__ */
