#ifndef __DEBUG_HXX__
#define __DEBUG_HXX__

#ifdef NDEBUG

#define DFN(x)
#define DEBUG_PRINT(x)

#else

#include <stdio.h>

void debug_acquire();
void debug_release();

#define DFN(x) const char DEBUG_FUNC_NAME[] = #x
#define DEBUG_PRINT(x) { debug_acquire(); printf("%s [%08X]: ", DEBUG_FUNC_NAME, GetCurrentThreadId()); printf x ; debug_release(); }

#endif

#endif /* __DEBUG_HXX__ */
