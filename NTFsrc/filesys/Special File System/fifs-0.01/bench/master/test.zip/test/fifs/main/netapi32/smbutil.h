#ifndef __SMB_UTIL_H__
#define __SMB_UTIL_H__

VOID
SmbInitDispTable(
    );

BOOL
IsSmb(
    PVOID psmb,
    DWORD dwSize
    );

LPSTR
SmbDispatch(
    UCHAR command,
    LPSTR buffer,
    PNT_SMB_HEADER pSmb,
    DWORD dwSize,
    DWORD dwOffset,
    BOOL bRequest
    );

LPSTR
Trans2Dispatch(
    USHORT cmd,
    LPSTR buffer,
    PNT_SMB_HEADER pSmb,
    DWORD dwSize,
    DWORD dwOffset,
    BOOL bRequest,
    PUCHAR *ppParameter,
    PUCHAR *ppData
    );

LPCSTR
NcbUnparseAsynch(
    UCHAR command
    );

LPCSTR
NcbUnparseCommand(
    UCHAR command
    );

LPCSTR
NcbUnparseRetCode(
    UCHAR retcode
    );

LPCSTR
SmbUnparseCommand(
    UCHAR command
    );

LPCSTR
SmbUnparseTrans2(
    USHORT code
    );

LPSTR
SmbDumpDate(
    LPSTR buffer,
    SMB_DATE Date
    );

LPSTR
SmbDumpTime(
    LPSTR buffer,
    SMB_TIME Time
    );

LPSTR
SmbDumpSecurityMode(
    LPSTR buffer,
    USHORT SecurityMode
    );

#endif
