#ifndef __SERVER_HXX__
#define __SERVER_HXX__

int InitServer();
int RunServer();
void CleanupServer();

#endif
