#ifndef __DUMP_SMB_H__
#define __DUMP_SMB_H__

LPSTR
DumpData(
    LPSTR buffer,
    PUCHAR data,
    DWORD size
    );

LPSTR
DumpNCB(
    LPSTR buffer,
    PNCB pncb,
    BOOL bIn
    );

LPSTR
DumpSMB(
    LPSTR buffer,
    PVOID psmb,
    DWORD dwSize,
    BOOL bRequest
    );

VOID
InitDump(
    );

VOID
CleanupDump(
    );

#endif
