#ifndef __NCB_UTIL_H__
#define __NCB_UTIL_H__

#ifdef __cplusplus__
extern "C" {
#endif

typedef UCHAR NETBIOS_NAME[NCBNAMSZ];

#define COPY_NETBIOS_NAME(to, from) memcpy(to, from, NCBNAMSZ)

PNCB
AllocateNCB(
    );

VOID
FreeNCB(
    PNCB pncb
    );

void
MakeNetbiosName(
    NETBIOS_NAME achDest,
    LPCSTR szSrc
    );

VOID
InitializeNCB(
    PNCB pncb,
    int command,
    int nLana,
    int lsn,
    NETBIOS_NAME callname,
    NETBIOS_NAME name
    );

#ifdef __cplusplus__
}
#endif

#endif /* __NCB_UTIL_H__ */
