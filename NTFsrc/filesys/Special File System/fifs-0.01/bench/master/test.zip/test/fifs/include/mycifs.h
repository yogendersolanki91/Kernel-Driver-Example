#ifndef __MY_CIFS_H__
#define __MY_CIFS_H__

#ifndef TIME
#define TIME LARGE_INTEGER
#endif

#ifndef CLONG
#define CLONG ULONG
#endif

#include "cifs.h"

#endif
