#include <windows.h>
#include "filter.hxx"
#include <debug.hxx>

filter_t::filter_t(
    const char* str
    ):wilds(false),all(false),s(0)
{
    if (!str) return;

    const char* start = str;
    while (*str) {
        wilds = wilds || ((*str) == '*') || ((*str) == '?');
        str++;
    }
    all = wilds && ((str - start) == 1);
    s = new char[str - start + 1];
    lstrcpy(s, start);
}

filter_t::filter_t(
    const filter_t& f
    ):wilds(f.wilds),all(f.all),s(0)
{
    if (f.s) {
        s = new char[lstrlen(f.s) + 1];
        lstrcpy(s, f.s);
    }
}

bool
filter_t::wildmatch(
    const char* str
    ) const
{
    DFN(filter_t::wildmatch);
    const bool found = true;
    DEBUG_PRINT(("wildmatch(%s) on filter (%s,%d,%d)...%s\n", 
                 str, s, wilds, all, found?"FOUND":"NOT found"));
    return found;
}

bool
filter_t::match(
    const char* str
    ) const
{
    DFN(filter_t::match);
    const bool found = !s || all || (wilds && wildmatch(str)) || (!wilds && !lstrcmpi(s, str));
    DEBUG_PRINT(("match(%s) on filter (%s,%d,%d)...%s\n", 
                 str, s, wilds, all, found?"FOUND":"NOT found"));
    return found;
}

filter_t::~filter_t()
{
    delete [] s;
}
