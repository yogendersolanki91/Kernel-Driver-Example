#ifndef __FILTER_HXX__
#define __FILTER_HXX__

class filter_t {
    char* s;
    bool wilds;
    bool all;
public:
    filter_t(const char* str);
    filter_t(const filter_t& f);
    bool wildmatch(const char* str) const;
    bool match(const char* str) const;
    ~filter_t();
};

#endif /* __FILTER_HXX__ */
