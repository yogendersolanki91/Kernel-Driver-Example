#include <windows.h>
#include "conf_nfs.hxx"
#include <conf_help.hxx>
#include <debug.hxx>

static const char USER_INFO[] = "UserInfo";

static const char DEFAULT_CONFIG_PATH[] = "\\Registry\\HKEY_LOCAL_MACHINE\\Software\\Etc\\fsnfs";

static const config_string_params csp_machine = { 
    "machine",
    "tma-1",
    -1
};
static const config_string_params csp_dirpath = { 
    "dirpath",
    "/disk/tm1",
    -1
};
static const config_string_params csp_protocol = { 
    "protocol",
    "udp",
    -1
};
static const config_string_params csp_Label = { 
    "Label",
    "fsnfs",
    -1
};
static const config_ranged_num_params crnp_MaxHandles = {
    "MaxHandles",
    256,
    256,
    0xFFFF
};

config_type config;

void
InitConfig(
    const char* config_path
    )
{
    DFN(InitConfig_win32);
    ZeroMemory(&config, sizeof(config_type));

    HKEY hKey = 0;
    DWORD error;

    const char* base_path = ConfigOpen(config_path, DEFAULT_CONFIG_PATH, 
                                       hKey, error);
    if (config_path && !base_path || (base_path == DEFAULT_CONFIG_PATH))
        DEBUG_PRINT(("Could not open config path %s (error %d)\n",
                     config_path, error));
    if (!base_path)
        DEBUG_PRINT(("Could not open default config path %s (error %d)\n", 
                     DEFAULT_CONFIG_PATH, error));

    RegGetRangedNumber2(hKey, crnp_MaxHandles, config.max_handles);
    RegGetString2(hKey, csp_machine, 0, config.machine);
    RegGetString2(hKey, csp_dirpath, 0, config.dirpath);
    RegGetString2(hKey, csp_protocol, 0, config.protocol);
    RegGetString2(hKey, csp_Label, 0, config.label);

    config.localmachine[0] = 0;
    gethostname(config.localmachine, MAX_MACHINE_NAME);
    config.localmachine[MAX_MACHINE_NAME] = 0;
    // we error-check later, when we actually try to use the file system

    config.hkey_user_info = INVALID_HANDLE_VALUE;
    RegOpenKeyEx(hKey, USER_INFO, 0, KEY_READ, &config.hkey_user_info);
    // we error-check later, when we actually try to use the file system

    RegCloseKey(hKey);
}

void
CleanupConfig()
{
    RegFreeString(config.machine);
    RegFreeString(config.dirpath);
    RegFreeString(config.protocol);
    RegFreeString(config.label);
    RegCloseKey(config.hkey_user_info);
}

DWORD
GetUserInfo(
    const char* principal, int& uid, int& gid, int& len, int gids[], int maxlen
    )
{
    DFN(GetUserInfo);
    if (!config.localmachine[0]) {
        DEBUG_PRINT(("could not get local machine name\n"));
        return ERROR_INVALID_PARAMETER;
    }
    if (config.hkey_user_info == INVALID_HANDLE_VALUE) {
        DEBUG_PRINT(("could not get user info key\n"));
        return ERROR_INVALID_PARAMETER;
    }
    HKEY hKey;
    DWORD error = RegOpenKeyEx(config.hkey_user_info, principal, 0, 
                               KEY_READ, &hKey);
    if (error) {
        DEBUG_PRINT(("could not get user info key for %s\n", principal));
        return error;
    }
    DWORD size;
    size = sizeof(uid);
    error = RegQueryValueEx(hKey, "uid", 0, NULL, (LPBYTE)&uid, &size);
    if (error) {
        DEBUG_PRINT(("could not get uid for %s\n", principal));
        RegCloseKey(hKey);
        return error;
    }
    size = sizeof(gid);
    error = RegQueryValueEx(hKey, "gid", 0, NULL, (LPBYTE)&gid, &size);
    if (error) {
        DEBUG_PRINT(("could not get gid for %s\n", principal));
        RegCloseKey(hKey);
        return error;
    }
    void* tmp;
    error = RegAllocQueryValue(hKey, "gids", tmp);
    if (error) {
        DEBUG_PRINT(("could not get gids for %s\n", principal));
        RegCloseKey(hKey);
        return error;
    }
    char* buffer = (char*)tmp;
    len = 0;
    char* tok = strtok(buffer, ",");
    while (tok && (len < maxlen)) {
        gids[len++] = atoi(tok);
        tok = strtok(0, ",");
    }
    RegFreeQueryValue((LPBYTE)tmp);
    if (!len) {
        DEBUG_PRINT(("could not parse any gids for %s\n", principal));
        RegCloseKey(hKey);
        return ERROR_INVALID_PARAMETER;
    }
    RegCloseKey(hKey);
    return ERROR_SUCCESS;
}
