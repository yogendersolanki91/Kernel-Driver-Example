#ifndef __CONFIG_HELP_HXX__
#define __CONFIG_HELP_HXX__

typedef char* subst_table_t[256];

struct config_string_params {
    const char* name;
    const char* def;
    int max_size;        // -1 for unlimited (includes NULL byte)
};

struct config_ranged_num_params {
    const char* name;
    DWORD def;
    DWORD min;
    DWORD max;
};

const char*
ConfigOpen(
    const char* config_path,
    const char* default_config_path,
    HKEY& hKey,
    DWORD& error
    );

char*
ConfigAllocPath(
    const char* base_path,
    char* path_candidate
    );

void
ConfigFreePath(
    char* path
    );

DWORD
ConfigOpenRegistry(
    LPCSTR RegistryPath,
    REGSAM samDesired,
    PHKEY phKey
    );

bool
RegGetRangedNumber2(
    HANDLE hKey,
    const config_ranged_num_params& p,
    DWORD& value
    );

bool
RegGetRangedNumber(
    HANDLE hKey,
    LPCSTR szValue,
    DWORD def,
    DWORD min,
    DWORD max,
    DWORD& value
    );

bool
RegGetString2(
    HANDLE hKey,
    const config_string_params& p,
    subst_table_t table, // 0 for no subst
    char*& target        // where to put string pointer
    );

bool
RegGetString(
    HANDLE hKey,
    const char* szValue, // value name
    const char* def,     // default value, if desired
    int max_size,        // -1 for unlimited (includes NULL byte)
    subst_table_t table, // 0 for no subst
    char*& target        // where to put string pointer
    );

void
RegFreeString(
    char* str
    );

int
substitute_vars(
    const char* string_template,
    char* buffer,
    int size,           // put 0 here to get necessary size
    subst_table_t table
    );

DWORD
RegAllocQueryValue(
    HKEY hKey,
    LPCSTR szValue,
    void*& pData
    );

void
RegFreeQueryValue(
    LPBYTE pData
    );

#endif /* __CONFIG_HELP_HXX__ */
