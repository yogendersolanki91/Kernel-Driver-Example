#ifndef __TRANS2_H__
#define __TRANS2_H__

LPSTR
Trans2QueryFsInfo(
    UCHAR command,
    LPSTR buffer,
    PNT_SMB_HEADER pSmb,
    DWORD dwSize,
    DWORD dwOffset,
    BOOL bRequest,
    PUCHAR *ppParameter,
    PUCHAR *ppData
    );

LPSTR
Trans2FindFirst2(
    UCHAR command,
    LPSTR buffer,
    PNT_SMB_HEADER pSmb,
    DWORD dwSize,
    DWORD dwOffset,
    BOOL bRequest,
    PUCHAR *ppParameter,
    PUCHAR *ppData
    );

LPSTR
Trans2FindNext2(
    UCHAR command,
    LPSTR buffer,
    PNT_SMB_HEADER pSmb,
    DWORD dwSize,
    DWORD dwOffset,
    BOOL bRequest,
    PUCHAR *ppParameter,
    PUCHAR *ppData
    );

#endif
