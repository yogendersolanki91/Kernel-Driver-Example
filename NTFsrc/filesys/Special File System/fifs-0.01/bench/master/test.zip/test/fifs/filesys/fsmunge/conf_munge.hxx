#ifndef __CONFIG_HXX__
#define __CONFIG_HXX__

struct config_type {
    char* fs_dll;
    char* fs_name;
    char* fs_config;
};

extern config_type config;

void InitConfig(const char* config_path);
void CleanupConfig();

#endif
