#ifndef __CONFIG_HXX__
#define __CONFIG_HXX__

struct config_type {
    char* root;
    char* label;
    unsigned long max_handles;
};

extern config_type config;

void InitConfig(const char* config_path);
void CleanupConfig();

#endif
