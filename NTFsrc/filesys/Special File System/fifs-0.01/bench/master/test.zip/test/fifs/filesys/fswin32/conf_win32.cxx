#include <windows.h>
#include "conf_win32.hxx"
#include <conf_help.hxx>
#include <debug.hxx>

static const char DEFAULT_CONFIG_PATH[] = "\\Registry\\HKEY_LOCAL_MACHINE\\Software\\Etc\\fswin32";

static const config_string_params csp_Root = { 
    "Root",
    "c:\\temp\\fakefs",
    -1
};
static const config_string_params csp_Label = { 
    "Label",
    "FsWin32",
    -1
};
static const config_ranged_num_params crnp_MaxHandles = {
    "MaxHandles",
    256,
    256,
    0xFFFF
};

config_type config;

void
InitConfig(
    const char* config_path
    )
{
    DFN(InitConfig_win32);
    ZeroMemory(&config, sizeof(config_type));

    HKEY hKey = 0;
    DWORD error;

    const char* base_path = ConfigOpen(config_path, DEFAULT_CONFIG_PATH, 
                                       hKey, error);
    if (config_path && !base_path || (base_path == DEFAULT_CONFIG_PATH))
        DEBUG_PRINT(("Could not open config path %s (error %d)\n",
                     config_path, error));
    if (!base_path)
        DEBUG_PRINT(("Could not open default config path %s (error %d)\n", 
                     DEFAULT_CONFIG_PATH, error));

    RegGetRangedNumber2(hKey, crnp_MaxHandles, config.max_handles);
    RegGetString2(hKey, csp_Root, 0, config.root);
    RegGetString2(hKey, csp_Label, 0, config.label);

    RegCloseKey(hKey);
}

void
CleanupConfig()
{
    RegFreeString(config.root);
    RegFreeString(config.label);
}
