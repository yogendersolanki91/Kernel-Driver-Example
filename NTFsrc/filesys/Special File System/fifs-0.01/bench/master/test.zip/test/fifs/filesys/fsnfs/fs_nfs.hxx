#ifndef __FS_NFS_HXX__
#define __FS_NFS_HXX__

#include <windows.h>
#include <fsinterface.hxx>

using namespace FsInterface;

///////////////////////////////////////////////////////////////////////////////
//
// Defines filesystem
//
///////////////////////////////////////////////////////////////////////////////

class Fs_NFS: public FileSystem {
public:
    ULONG AddRef();
    ULONG Release();
    
    DWORD connect(const char* principal, FsDispatchTable** ppDT);

private:
    Fs_NFS(const char* config_path);
    ~Fs_NFS();

    // helpers:
    DWORD init();

    // global:
    static ULONG global_count;

    // data:
    ULONG ref_count;
    CRITICAL_SECTION csObject;

    // friends:
    friend BOOL WINAPI DllMain(HINSTANCE, DWORD, LPVOID);
    friend DWORD WINAPI FileSystemCreate(LPCSTR, LPCSTR, DWORD, FileSystem**);
};

#endif /* __FS_NFS_HXX__ */
