#ifndef __TRANS2_HXX__
#define __TRANS2_HXX__

#ifndef __cplusplus
#error "C++ compiler required"
#endif

template<class T>
inline
size_t
SIZEOF_TRANS2_RESP_HEADER(
    T* resp
    )
{
    return sizeof(T) + (1 + resp->SetupCount)*sizeof(USHORT);
}

BOOL
Trans2Unknown(
    DPB* dpb,
    T2B* t2b
    );

BOOL
Trans2QueryFsInfo(
    DPB* dpb,
    T2B* t2b
    );

BOOL
Trans2FindFirst2(
    DPB* dpb,
    T2B* t2b
    );

BOOL
Trans2FindNext2(
    DPB* dpb,
    T2B* t2b
    );

BOOL
Trans2QueryPathInfo(
    DPB* dpb,
    T2B* t2b
    );

BOOL
Trans2SetPathInfo(
    DPB* dpb,
    T2B* t2b
    );

BOOL
Trans2QueryFileInfo(
    DPB* dpb,
    T2B* t2b
    );

BOOL
Trans2SetFileInfo(
    DPB* dpb,
    T2B* t2b
    );

#endif
