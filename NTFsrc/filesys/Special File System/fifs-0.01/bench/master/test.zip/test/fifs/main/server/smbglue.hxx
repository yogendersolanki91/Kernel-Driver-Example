#ifndef __SMB_GLUE_HXX__
#define __SMB_GLUE_HXX__

#include "fsinterface.hxx"
#include "filter.hxx"

using namespace FsInterface;

// user/uid

bool
is_authenticated_user(
    const char *name, 
    void* pwd,
    int pwd_size
    );

USHORT
add_user(
    const char *name,
    FsDispatchTable* pDisp
    );

FsDispatchTable*
get_user(
    USHORT uid
    );

bool
del_user(
    USHORT uid
    );

// find/sid

USHORT
add_find(
    fhandle_t fh,
    const char* filter_str
    );

bool
save_find_cookie(
    USHORT sid,
    UINT32 cookie
    );

bool
get_find(
    USHORT sid,
    fhandle_t* pfh,
    const filter_t** pfilter,
    UINT32* pcookie
    );

bool
del_find(
    USHORT sid
    );

// file/fid

USHORT
add_file(
    fhandle_t fh
    );

fhandle_t
get_file(
    USHORT fid
    );

bool
del_file(
    USHORT fid
    );

// init/cleanup

void
smbglue_init(
    void
    );

void
smbglue_reset(
    void
    );

void
smbglue_cleanup(
    void
    );

#endif
