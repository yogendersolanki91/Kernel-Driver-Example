#ifndef __RPC_NT_H__
#define __RPC_NT_H__

extern int rpc_nt_init(void);
extern int rpc_nt_exit(void);
extern void nt_rpc_report();

#endif /* __RPC_NT_H__ */
