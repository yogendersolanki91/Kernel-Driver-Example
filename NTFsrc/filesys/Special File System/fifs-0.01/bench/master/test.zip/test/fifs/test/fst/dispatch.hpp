#ifndef __DISPATCH_HPP__
#define __DISPATCH_HPP__

typedef int (*DISPATCH_FUNC)(const char*, const char*, int, char *[]);

#define DECLARE_DISPATCH_FUNC(name) \
int name(const char* program, const char* command, int argc, char *argv[])

class CCommandLineDispatcher_Rep;

class CCommandLineDispatcher
{
private:
    CCommandLineDispatcher_Rep *rep;
public:
    CCommandLineDispatcher();
    ~CCommandLineDispatcher();
    void Add(
        const char *name,
        DISPATCH_FUNC exec
        );
    int Dispatch(
        int argc,
        char* argv[]
        );
    int DoCommand(
        const char *program, 
        char *command, 
        int argc, 
        char *argv[]
        );
};

#endif // __DISPATCH_HPP
