#include <windows.h>
#include "conf_munge.hxx"
#include <conf_help.hxx>
#include <debug.hxx>

static const char DEFAULT_CONFIG_PATH[] = "\\Registry\\HKEY_LOCAL_MACHINE\\Software\\Etc\\fsmunge";

static const config_string_params csp_FsDll = { 
    "FsDll",
    "fsnfs.dll",
    -1
};
static const config_string_params csp_FsName = { 
    "FsName",
    "fsnfs",
    -1
};
static const config_string_params csp_FsConfig = { 
    "FsConfig",
    "fsnfs",
    -1
};

config_type config;

void
InitConfig(
    const char* config_path
    )
{
    DFN(InitConfig_win32);
    ZeroMemory(&config, sizeof(config_type));

    HKEY hKey = 0;
    DWORD error;

    const char* base_path = ConfigOpen(config_path, DEFAULT_CONFIG_PATH, 
                                       hKey, error);
    if (config_path && !base_path || (base_path == DEFAULT_CONFIG_PATH))
        DEBUG_PRINT(("Could not open config path %s (error %d)\n",
                     config_path, error));
    if (!base_path)
        DEBUG_PRINT(("Could not open default config path %s (error %d)\n", 
                     DEFAULT_CONFIG_PATH, error));

    RegGetString2(hKey, csp_FsDll, 0, config.fs_dll);
    RegGetString2(hKey, csp_FsName, 0, config.fs_name);
    char* candidate_path = 0;
    RegGetString2(hKey, csp_FsConfig, 0, candidate_path);

    RegCloseKey(hKey);

    config.fs_config = ConfigAllocPath(base_path, candidate_path);
    RegFreeString(candidate_path);
}

void
CleanupConfig()
{
    RegFreeString(config.fs_dll);
    RegFreeString(config.fs_name);
    ConfigFreePath(config.fs_config);
}
