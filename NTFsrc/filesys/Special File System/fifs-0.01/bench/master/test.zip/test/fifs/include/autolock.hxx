#ifndef __AUTOLOCK_HXX__
#define __AUTOLOCK_HXX__

class AutoLock {
    LPCRITICAL_SECTION pcs;
public:
    AutoLock(LPCRITICAL_SECTION _pcs):pcs(_pcs) { EnterCriticalSection(pcs); }
    ~AutoLock() { LeaveCriticalSection(pcs); }
};

#endif /* __AUTOLOCK_HXX */
