#include <windows.h>
#include "debug.hxx"

static CRITICAL_SECTION cs;
//DWORD dwTlsIndex = 0xFFFFFFFF;

BOOL WINAPI 
DllMain(
    HINSTANCE hinstDLL, // handle to DLL module
    DWORD fdwReason, // reason for calling function
    LPVOID lpvReserved // reserved
    )
{
    switch (fdwReason) {
    case DLL_PROCESS_ATTACH:
//         dwTlsIndex = TlsAlloc();
//         if (dwTlsIndex == 0xFFFFFFFF)
//             return FALSE;
//         TlsSetValue(dwTlsIndex, 0);
        InitializeCriticalSection(&cs);
        break;
    case DLL_PROCESS_DETACH:
//         TlsFree(dwTlsIndex);
        DeleteCriticalSection(&cs);
        break;
    case DLL_THREAD_ATTACH:
//        TlsSetValue(dwTlsIndex, 0);
        break;
    case DLL_THREAD_DETACH:
        break;
    }
    return TRUE;
}

void debug_acquire()
{
    EnterCriticalSection(&cs);
}

void debug_release()
{
    LeaveCriticalSection(&cs);
}
