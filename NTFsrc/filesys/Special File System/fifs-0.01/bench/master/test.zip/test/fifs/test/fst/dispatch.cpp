#include "dispatch.hpp"
#include <string.h>
#include <iostream>
#include <vector>

struct DISPATCH_ENTRY {
    char *name;
    DISPATCH_FUNC exec;
};

bool operator < (const DISPATCH_ENTRY& x, const DISPATCH_ENTRY& y) {
        return strcmp(x.name, y.name) < 0;
}

bool operator == (const DISPATCH_ENTRY& x, const DISPATCH_ENTRY& y) {
    return !strcmp(x.name, y.name);
}

class CCommandLineDispatcher_Rep
{
private:
    std::vector<DISPATCH_ENTRY> disp_table;
    friend class CCommandLineDispatcher;
};

CCommandLineDispatcher::CCommandLineDispatcher()
{
    rep = new CCommandLineDispatcher_Rep;
}

CCommandLineDispatcher::~CCommandLineDispatcher()
{
    delete rep;
}

void
CCommandLineDispatcher::Add(
    const char *name,
    DISPATCH_FUNC exec
    )
{
    DISPATCH_ENTRY entry;
    entry.name = (char*) name;
    entry.exec = exec;
    rep->disp_table.push_back(entry);
}

int
CCommandLineDispatcher::Dispatch(
    int argc,
    char* argv[]
    )
{
    if (argc < 2) {
        std::cout << "Usage: " << argv[0] << " command [args]\n"
                  << "    Where 'command' is one of:\n";
        for (int i = 0; i < rep->disp_table.size(); i++) {
            std::cout << "        " << rep->disp_table[i].name << "\n";
        }
        return 1;
    }
    return DoCommand(argv[0], argv[1], argc - 2, &argv[2]);
}

int
CCommandLineDispatcher::DoCommand(
    const char *program, 
    char *command, 
    int argc, 
    char *argv[]
    )
{
    for (int i = 0; i < rep->disp_table.size(); i++) {
        if (!stricmp(rep->disp_table[i].name, command)) {
            return rep->disp_table[i].exec(program, command, argc, argv);
        }
    }
    std::cout << "Command " << command << " not found\n";
    return -1;
}
